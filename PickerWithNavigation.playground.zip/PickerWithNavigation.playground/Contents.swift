import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    let students = ["Harry", "Hermione", "Ron"]
    @State private var selectedStudent = ""
    
    var body: some View {
        NavigationStack {
            Form {
                Picker("Selected Student", selection: $selectedStudent) {
                    ForEach(students, id: \.self) { student in
                        Text(student)
                    }
                }
            }
            .navigationTitle("Select a Student")
        }
    }
}

PlaygroundPage.current.setLiveView(ContentView())
